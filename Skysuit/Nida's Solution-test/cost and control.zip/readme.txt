Delete un attached volumes:
    - create volume which are attched.
    -  create volume which are not attached.



Delete OLD EBS Snapshots:
    - Create EBS Snapshots.
    - few with tag DoNotDelete True
    - few with tag DoNotDelete False
    - few with no tag


-	DB is stopped to couldn’t get the snapshots of that db.
-	DB is running, so can get the snapshots of that db
-   Snapshots of Aurora DB engine doesn't shown. 