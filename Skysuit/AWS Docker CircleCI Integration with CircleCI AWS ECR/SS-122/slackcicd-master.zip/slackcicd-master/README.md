# slackcicd
Slack Bot for Kubernetes CI/CD
