# **Consolidated Cross-Master Account Billing Visualization**

The designed solution is able to collect AWS Cost and Usage Reports from multiple master accounts i.e master collector account and master billing source account at **central account i.e master collector account. Report of Master Account will be detailing the costs for their all member/linked accounts. The AWS Cost & Usage Report contains the most comprehensive information available on costs and usage. To extract value quickly from your AWS Cost & Usage Report, query the underlying data source using Amazon Athena.

## **AWS Services Used In Solution**

- AWS Cost and Usage report.

- AWS S3 - to keep reports.

- AWS Glue Crawler - it runs periodically, scans the data and automatically populate the AWS Glue Data Catalog.

- AWS Glue Data Catalog - once data in Glue Data Catalog, it readily available to querying in Athena. 

- AWS Athena DataBase.

- AWS Lambda Function.

- AWS CloudFormation Template - to automate the solution.

- AWS QuickSight - to visualize the cost and usage reports.

## Solution Design

![consolidated_billing_img](https://user-images.githubusercontent.com/60149354/90391707-00743f00-e0a7-11ea-94cf-2341425758b6.png)

## Deployment

| ***SrNo.\*** | ***File\***                                                 |           ***Launch in\***           | ***Description\***                                           | ***Location\***                                           |
| ------------ | ----------------------------------------------------------- | :----------------------------------: | ------------------------------------------------------------ | --------------------------------------------------------- |
|              | **Cloudformation  Template (Yaml)**                         |       **Master**   **Account**       |                                                              |                                                           |
| 1            | consolidated_billing_assume_role_&_new_bucket               |            **Collector**             | Create assume  role for cross account (replication, replica bucket creation for cur report  and organization accounts detail put into csv file) | eq-skybase\Consolidated-Billing\CloudFormation  Templates |
| 2            | consolidated_billing_cur_report.yml                         |   **Billing source** | Create s3 bucket  and configure CUR report                   | eq-skybase\Consolidated-Billing\CloudFormation  Templates |
| 3            | consolidated_billing_replication_cross_account_crhelper.yml |          **Billing source**          | Create CUR report  replica s3 bucket in master collector (eqtest) and configure replication  configuration. | eq-skybase\Consolidated-Billing\CloudFormation  Templates |
| 4            | consolidated_billing_accts_detail.yaml                      | **Billing source** | Fetch  organization accounts detail put into csv file in the bucket in master  collector (eqtest) | eq-skybase\Consolidated-Billing\CloudFormation  Templates |
| 5            | Consolidated_billing_s3_glue_crawler_athena.yaml            |            **Collector**             | Create a crawler,  Database and Athena table. It will be able to get Account aliases details  from csv file and put in athena table to be queried with other tables in  quicksight | eq-skybase\Consolidated-Billing\CloudFormationTemplates   |
|              | **Nested Template  (Yaml)**                                 |                                      |                                                              |                                                           |
| 1            | Consolidated_billing_nested_template.yml                    | **Billing source** |                                                              | eq-skybase\Consolidated-Billing\CloudFormationTemplates   |
|              |                                                             |                                      |                                                              |                                                           |
|              | **Lambda Code**   **( Python )**                            |                                      |                                                              |                                                           |
| 1            | consolidated_billing_accts_detail                           | **Billing source** |                                                              | eq-skybase\Consolidated-Billing\Lambdas                   |
| 2            | consolidated_billing_cur_report                             | **Billing source** |                                                              | eq-skybase\Consolidated-Billing\Lambdas                   |
| 3            | consolidated_billing_replication                            |          **Billing source**          |                                                              | eq-skybase\Consolidated-Billing\Lambdas                   |
| 4            | consolidated_billing_crawler_initializer                    |          **Billing source**          |                                                              | eq-skybase\Consolidated-Billing\Lambdas                   |
|              |                                                             |                                      |                                                              |                                                           |

​    

### **Parameters in Template**

| Parameter             | Description                                                  | Allowed values                               |
| --------------------- | ------------------------------------------------------------ | -------------------------------------------- |
| MasterAcct            | Master Account in which your are going to run this template  | must specify billing source, collector       |
| OrganizationName      | Organization name                                            | eqtest , eqskybase, etc                      |
| LambdaCodeBucketName  | S3 bucket name which contain lambda code                     | ns-rep-lambda-code                           |
| CURS3Key              | CUR report configuration lambda zip file                     | Consolidated_Billing_Cur_Report.zip          |
| S3Prefix              | S3Prefix for CUR report                                      | eqskybase \| eqtest                          |
| S3Region              | S3 Region                                                    | us-east-1                                    |
| DestinationBucketName | Replica of CUR report s3 bucket                              | replica-eqskybase-cur-report-bucket          |
| RepS3Key              | zip file for s3 b replication lambda                         | Consolidated_Billing_Replication.zip         |
| SourceAcctId          | Billing source (i.e. eqskybase) account Id                   | 112520250899                                 |
| DestinationAcctId     | Collector(i.e. eqtest) account Id                            | 224233068863                                 |
| AssumeRoleName        | Assume role name for replication created in master collector account | NS-assume-role-replication                   |
| Organization          | Master account name in which organization accounts detail is required | i.e. eqtest, eqskybase                       |
| TargetBucket          | Bucket name which is created in master collector account with assume role | consolidated-billing-organization-detail     |
| TargetFileName        | csv File name in which organization accounts detail going to save | i.e. aliases.csv                             |
| AcctS3Key             | zip file for Organization accounts detail lambda             | Consolidated_Billing_Accts_Detail.zip        |
| CFNCrawlerName        | Crawler name which is going to start                         | cfn-crawler                                  |
| CFNDatabaseName       | Crawler database name                                        | cfn-database                                 |
| CFNTablePrefixName    | Crawler table prefix                                         | cfn-sample                                   |
| CrawlerS3Key          | zip file for crawler initializer lambda                      | Consolidated_Billing_crawler_initializer.zip |

## **Deployment steps**

1. Steps for Collector Master Account
   - Sign Up AWS Quick Sight in Collector Master Account. That will used for visualization of all CUR of master accounts.
   - Deploy consolidated_billing_assume_role_&_new_bucket.yaml . It will create following resources i.e  assume_role.
   - Bucket C - have csv file containing organization account’s names and IDs.

2. Steps for Billing Source Master Account.
   - Deploy Consolidated_billing_nested_template.yaml. It will create following resources.
   - consolidated_billing_cur_report.yaml will configure:
      - AWS CUR report.
      - Bucket B - for reports.
    - consolidated_billing_replication_cross_account_crhelper.yaml will do following:
       - Create Destination_Bucket in Collector Master Account 
       - Add Replication rule on Bucket B. It will replicate the objects from Bucket B to Destination_Bucket.
    - consolidated_billing_accts_detail.yaml will create:
       - consolidated_billing_accts_detail.py - It will fetch account names and its corresponding IDs from AWS Organization and puts in file named in Bucket_C using assume_role.
       
3. Steps for Collector Master Account.
   - Deploy Consolidated_billing_nested_template.yaml in collector master account. It will create following resources.
   - consolidated_billing_cur_report.yaml will configure:
      - AWS CUR Report.
      - Bucket A - for reports.
   - consolidated_billing_accts_detail.yaml will create:
      - consolidated_billing_accts_detail.py - It will fetch account names and its corresponding IDs from AWS Organization and puts in file in Bucket_C
   - consolidated_billing_s3_glue_crawler_athena.yaml will create following:
      - AWS Glue Crawler - to crawls on Bucket C.
      - AWS Glue DataBase - crawler will populate it when ever there is new data in Bucket C.
      - consolidated_billing_crawler_initializer.py - to initialize the crawler.
      - Athena Table - having data from csv file in table form.

4. Wait till receive templates in Bucket A and Destination_Bucket.

5. Main_Template_A.yaml 
   - After receiving main_template_A in Bucket A, run it. It will create following:
     - Crawler - to crawles on Bucket A.
     - Data Catalog - populated by crawler when there is change in Bucket A.
     - Initializer Lambda - triggers on updation of Bucket A and starts crawler.
     - Notification Lambda - sets up notification event on Bucket A.
     - Athena Table - contains CUR report in tabular form which is easy to be quered in Quick Sight.

6. Main_Template_B.yaml
    - After receiving main_template_B in Destination_Bucket, change the bucket name from Bucket B to Destination_Bucket in template and run it. It will create following:
      - Crawler - to crawles on Destination_Bucket.
      - Data Catalog - populated by crawler when there is change in Destination_Bucket
      - Initializer Lambda - triggers on updation of Destination_Bucket and starts crawler.
      - Notification Lambda - sets up notification event on Destination_Bucket.
      - Athena Table - contains CUR report in tabular form which is easy to be quered in Quick Sight.

### **AWS QuickSight**

Once all data is ready in the tables of Athena, there’s need to execute the Custom SQL query in AWS QuickSight. In QuickSight perform following steps:

1. Go to Manage QuickSight.
2. Select **Security and Permissions** from left pane.
3. Choose **Add or Remove.**
4. Choose **Select S3 Buckets.**
5. Check Bucket A, Destination_Bucket and Bucket C.
6. Click on Finish and then Update.
7. Go to QuickSight Manage Data.
8. On the **Your Data Sets** page, choose **New data set**.
9. In the **FROM NEW DATA SOURCES** section of the **Create a Data Set** page, choose the **Athena** data source icon.
10. For **Data source name**, enter a descriptive name for the data source connection. 
11. On the **Choose your table** screen, choose **Use custom SQL**. Enter your query, or a placeholder query such as SELECT 1, and choose **Confirm SQL**.
12. Load data into memory with [SPICE](https://docs.aws.amazon.com/quicksight/latest/user/welcome.html#spice), choose **Import to SPICE for quicker analytics**. The green indicator shows whether you have space available.
13. To prepare the data before creating an analysis, choose **Edit/Preview data**. This opens the data preparation screen. When you are finished editing the dataset, choose **Save & Visualize** to go to analysis.
14. Perform following steps to create refresh schedule on dataset.
    1. On the **Your Data Sets** page, choose the dataset, and then choose **Schedule refresh**.
    2. For **Schedule Refresh**, choose **Create**.
    3. On the **Create a Schedule** screen, choose settings for your schedule.
       1. For **Time zone**, choose the time zone that applies to the data refresh.
       2. For **Repeats**, choose one of the following:
          - For Standard or Enterprise editions, you can choose **Daily**, **Weekly**, or **Monthly**.
            - **Daily**: Repeats every day
            - **Weekly**: Repeats on the same day of each week
            - **Monthly**: Repeats on the same day number of each month. To refresh data on the 29th, 30th or 31st day of the month, choose **Last day of month** from the list.
    4. **Starting**: Choose a date for the refresh to start.
    5. For **At**, Specify the time that the refresh should start. Use HH:MM and 24-hour format, for example 13:30.
