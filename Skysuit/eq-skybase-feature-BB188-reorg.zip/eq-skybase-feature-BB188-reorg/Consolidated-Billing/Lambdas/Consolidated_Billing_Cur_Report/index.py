from crhelper import CfnResource
import json
import boto3
import os
import logging


logger = logging.getLogger()
logger.setLevel(logging.INFO)

class Const():
    KEY_RESOURCE_PROPERTIES = "ResourceProperties"
    KEY_BUCKET = "cur_bucket_name"
    KEY_REPORT = "cur_report_name"
    KEY_PREFIX = "s3prefix"
    KEY_REGION = "cur_region"
    TIME_UNIT_HOURLY = "HOURLY"
    TIME_UNIT_DAILY = "DAILY"
    REPORT_FORMAT = "Parquet"
    
HELPER = CfnResource()
CUR_CLIENT = boto3.client('cur')
S3_CLIENT = boto3.client('s3')

@HELPER.create
@HELPER.update
def create(event, context):
    
    cur_bucket_name = (event[Const.KEY_RESOURCE_PROPERTIES][Const.KEY_BUCKET])                            #  CUR bucket name
    cur_report_name = (event[Const.KEY_RESOURCE_PROPERTIES][Const.KEY_REPORT])                            #  CUR report name
    s3_prefix = (event[Const.KEY_RESOURCE_PROPERTIES][Const.KEY_PREFIX])                                  #  S3 Prefix  e.g (skybase/curreport)
    region = (event[Const.KEY_RESOURCE_PROPERTIES][Const.KEY_REGION])                                     #  Region
    
    # Create an destination s3 bucket
    create_bucket(cur_bucket_name, region)

          
    # Put bucket policy for cur report
    put_bucket_policy(cur_bucket_name)
    
    # Create CUR report
    create_cur_report(cur_bucket_name, cur_report_name, s3_prefix, region)
 
# Create an destination s3 bucket 
def create_bucket(bucket, region):

    logger.info("in create_bucket")  # reviewnotes: this should be "in create_bucket
    
    bucket_response = S3_CLIENT.create_bucket(
        Bucket=bucket)
        # ,
        # CreateBucketConfiguration={
        #   'LocationConstraint': region})
        
# Create CUR report
def create_cur_report(bucket, report, s3_prefix, region):

    logger.info("in create_cur_report ") # reviewnotes: this should be "in create_cur_report"
    
    CUR_CLIENT.put_report_definition(
    ReportDefinition={
        'ReportName': report,
        'TimeUnit': Const.TIME_UNIT_HOURLY,
        'Format': Const.REPORT_FORMAT,
        'Compression': 'Parquet',
        'AdditionalSchemaElements': [
            'RESOURCES',
        ],
        'S3Bucket': bucket,
        'S3Prefix': s3_prefix,
        'S3Region': region,
        'AdditionalArtifacts': [
            'ATHENA',
        ],
        'RefreshClosedReports': True,
        'ReportVersioning': 'OVERWRITE_REPORT'
    }
)


# Put bucket policy for cur report
def put_bucket_policy(bucket):

    logger.info("in put_bucket_policy") # reviewnotes: this should be "in put_bucket_policy"
    
    bucket_policy= {
        "Version": "2008-10-17",
        "Id": "Policy1335892530063",
        "Statement": [{
            "Sid": "Stmt1335892150622",
            "Effect": "Allow",
            "Principal": {
                "Service": "billingreports.amazonaws.com"
            },
            "Action": [
                "s3:GetBucketAcl",
                "s3:GetBucketPolicy"
            ],
            "Resource": "arn:aws:s3:::"+bucket
        },
		{
            "Sid": "Stmt1335892526596",
            "Effect": "Allow",
            "Principal": {
                "Service": "billingreports.amazonaws.com"
            },
            "Action": "s3:PutObject",
            "Resource": "arn:aws:s3:::"+bucket+"/*"
        }
		]
        }
    bucket_policy_conversion = json.dumps(bucket_policy)
    bucket_policy_destination = S3_CLIENT.put_bucket_policy(Bucket= bucket, Policy= bucket_policy_conversion)

def handler(event, context):

    try:
      HELPER(event, context)
    except Exception as e:
      logger.error(e)   # reviewnotes:   what happens when there is an error in the invokation, will the cloudformation know? for example if the CUR bucket already exists?

    logger.info('In Main Lambda Handler.')
    logger.info(json.dumps(event))


    
