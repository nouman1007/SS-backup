from crhelper import CfnResource
import json
import boto3
import csv 
import os
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

sts_connection = boto3.client('sts')
acct_b = sts_connection.assume_role(
    RoleArn= os.environ['AssumeRoleArn'],
    RoleSessionName="cross_acct_lambda"
    )
ACCESS_KEY = acct_b['Credentials']['AccessKeyId']
SECRET_KEY = acct_b['Credentials']['SecretAccessKey']
SESSION_TOKEN = acct_b['Credentials']['SessionToken']


HELPER = CfnResource()
# create service client using the assumed role credentials, e.g. S3
client = boto3.client('s3',aws_access_key_id=ACCESS_KEY,aws_secret_access_key=SECRET_KEY,aws_session_token=SESSION_TOKEN,)
organization_client = boto3.client('organizations')


# Global Variables
FILE_EXIST = {'File_Exist': True}



class Const():
    KEY_ID              = "Id"
    KEY_NAME            = "Name"
    KEY_ACCOUNTS        = "Accounts"
    KEY_NEXT_TOKEN      = "NextToken"
    KEY_LOCAL_FILE      = "/tmp/downloaded.csv"
    HEADER_CSV          = ['Master_Account', 'Account_Name', 'Account_ID']
    KEY_RESOURCE_PROPERTIES = "ResourceProperties"
    KEY_TARGET_BUCKET  = "target_bucket_name"
    KEY_TARGET_FILE_NAME = "file_name"
    KEY_ORGANIZATION_NAME = "organization"
    
    
# reviewnotes: There is no delete implementation . is this intentional?
    
@HELPER.create
@HELPER.update
def create(event, context):
    
    logger.info('In create') # reviewnotes: should be "In create"
    
    
    # variables
    target_bucket = (event[Const.KEY_RESOURCE_PROPERTIES][Const.KEY_TARGET_BUCKET])                    #  Target bucket
    target_file_name = (event[Const.KEY_RESOURCE_PROPERTIES][Const.KEY_TARGET_FILE_NAME])              #  Target file name
    organization_name = (event[Const.KEY_RESOURCE_PROPERTIES][Const.KEY_ORGANIZATION_NAME])            #  Organization
    
    
    #Function definations.
    remove_file(Const.KEY_LOCAL_FILE) 
    download_file(target_bucket, target_file_name)
    organization_accounts = get_organization_accounts(organization_name)
    write_to_file(organization_accounts)
    upload_to_s3(target_bucket, target_file_name) 
    

def remove_file(file_name):
    if os.path.exists(file_name):
        os.remove(file_name)
    else:
        print("File does not exist!")   # reviewnotes: use logger.info instead of print
        

def download_file(target_bucket, target_file_name):
    logger.info("In Download file from s3")
    
    try:
        response = client.list_objects(
            Bucket = target_bucket,
            Prefix = target_file_name
        )
        if 'Contents' in response:
            client.download_file(target_bucket, target_file_name, Const.KEY_LOCAL_FILE)   
        else:
            FILE_EXIST['File_Exist'] = False      
    except Exception as err:
        logger.error("send(..) failed to get file from bucket : " + str(err)) # reviewnotes: This would result in errors being supressed .i.e logged and not bubbled up. is this intentional?
        
    logger.info("This function successfully executed. and downloaded file. ")  # reviewnotes: this is incorrect. as per the error handler above errors will be suppressed. is this intentional? i.e if there are errors are they to be ignored?

def write_header():
    """
    This function writes header on file if size of file is zero.
    """
    
    logger.info("In writing Header function....")
    if os.path.isfile(Const.KEY_LOCAL_FILE) == False:
        with open(Const.KEY_LOCAL_FILE, 'w+') as csv_file:
            writing = csv.writer(csv_file)
            writing.writerow(Const.HEADER_CSV)
        csv_file.close()
        
    logger.info("Header written successfully!!!") 
    
    
def get_old_accounts():
    """
    This function reads content from file.
    Parameter.
    --------
    oldaccountlist:list
        Collects the existing content of file.
    """
    with open(Const.KEY_LOCAL_FILE, "r") as csv_file:
        reader = csv.reader(csv_file)
        # next(reader)
        old_account_list = list(reader)
    csv_file.close()
    return old_account_list        
        


def get_organization_accounts(organization_name):
    """
    This function get list of all accounts from organization.
    Returns
    ----
    list
        Returns list of Account details got from organization.
    """
    
    logger.info("In getting account ids and names")
    
    organization_accounts = []
    
    try:
        response = organization_client.list_accounts()
        organization_accounts += response[Const.KEY_ACCOUNTS]
        
        while(Const.KEY_NEXT_TOKEN in response.keys()):
            response = organization_client.list_accounts(NextToken = response[Const.KEY_NEXT_TOKEN])
            organization_accounts += response[Const.KEY_ACCOUNTS]
            
    except Exception as e:
        logger.error("send(..) failed to get account information: " + str(e))   # reviewnotes: This would result in errors being supressed .i.e logged and not bubbled up. is this intentional?
    
    
    organization_accounts = [[organization_name,org_account['Name'],org_account['Id']] for org_account in organization_accounts]

    return organization_accounts
    logger.info("I have recieved account ids and names successfully!!!")    
    
def write_to_file(org_accounts):
    """
    This function compares two list and writes new account details in result list.
    Then append account's details in csv file.
    Parameters.
    -------
    oldaccountlist:list
        list of existing account details in file.
    org_accounts:list
        list of account details from organization account.
    """
    
    logger.info("In writing to file function!!!")
    
    result_list = []
    if not FILE_EXIST['File_Exist']:
        write_header()
        result_list = org_accounts
        
    
    else:
        old_accounts = get_old_accounts()
        for i in org_accounts:
            if i not in old_accounts:
                result_list.append(i)           
            
    try:
        csv_file = open(Const.KEY_LOCAL_FILE, "a+")
        writing = csv.writer(csv_file)
        writing.writerows(result_list)
    except Exception as e:
        logger.error("send(..) failed to write in file: " + str(e)) # reviewnotes: This would result in errors being supressed .i.e logged and not bubbled up. is this intentional?
        
        
def upload_to_s3(target_bucket, target_file_name):
    """
    This fucntion uploads file to s3.
    """
    logger.info("in upload to s3")
    
    try:
        client.upload_file(Const.KEY_LOCAL_FILE, target_bucket, target_file_name)
    except Exception as err:
        logger.error("send(..) failed to upload file to bucket : " + str(err)) # reviewnotes: This would result in errors being supressed .i.e logged and not bubbled up. is this intentional?
    logger.info("File uploaded to bucket!")    
    
    
def handler(event, context):
    # reviewnotes:  log incoming event to help with troubleshooting
    HELPER(event, context)