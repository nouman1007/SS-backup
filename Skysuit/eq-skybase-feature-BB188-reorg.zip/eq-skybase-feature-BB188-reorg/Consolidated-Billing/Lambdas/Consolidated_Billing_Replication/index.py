
from crhelper import CfnResource
import boto3
import json
import os
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)


class Const():
    KEY_RESOURCE_PROPERTIES = "ResourceProperties"
    KEY_SOURCE = "source"
    KEY_DESTINATION = "destination"
    KEY_SOURCE_ACCT_ID = "source_acct_id"
    KEY_DESTINATION_ACCT_ID = "destination_acct_id"
    KEY_REPLICATION_ROLE = "s3_replication_role"
    KEY_DESTINATION_REGION = "des_bucket_region"

     

STS_CONNECTION = boto3.client('sts')

ACCT_B = STS_CONNECTION.assume_role(
    RoleArn= os.environ['AssumeRoleArn'],
    RoleSessionName="cross_acct_lambda"
    )

ACCESS_KEY = ACCT_B['Credentials']['AccessKeyId']
SECRET_KEY = ACCT_B['Credentials']['SecretAccessKey']
SESSION_TOKEN = ACCT_B['Credentials']['SessionToken']

# create service client using the assumed role credentials, e.g. S3
DESTINATION_S3 = boto3.client(
    's3',
    aws_access_key_id=ACCESS_KEY,
    aws_secret_access_key=SECRET_KEY,
    aws_session_token=SESSION_TOKEN,
    )

HELPER = CfnResource()
SOURCE_S3 = boto3.client('s3')


# reviewnotes: There is not delete implementation is this intentional?

@HELPER.create
@HELPER.update
def create(event, context):

    logger.info("in Create of bucket , puting bucket policy and replication Rule ")

    source_bucket = (event[Const.KEY_RESOURCE_PROPERTIES][Const.KEY_SOURCE])                            #  Source bucket name
    destination_bucket = (event[Const.KEY_RESOURCE_PROPERTIES][Const.KEY_DESTINATION])                  #  Destination bucket name
    source_bucket_acct_id = (event[Const.KEY_RESOURCE_PROPERTIES][Const.KEY_SOURCE_ACCT_ID])            #  Source Account ID
    destination_bucket_acct_id = (event[Const.KEY_RESOURCE_PROPERTIES][Const.KEY_DESTINATION_ACCT_ID])  #  destination Account ID
    replication_role = (event[Const.KEY_RESOURCE_PROPERTIES][Const.KEY_REPLICATION_ROLE])               #  Replication role
    destination_region = (event[Const.KEY_RESOURCE_PROPERTIES][Const.KEY_DESTINATION_REGION])           #  Destination Region
    
    # Create new bucket in destination account
    create_bucket(destination_bucket, destination_region)
    
    # Versioning enabling on source bucket
    update_bucket_versioning (source_bucket, 'Enabled', 'source')
    update_bucket_versioning (destination_bucket, 'Enabled', 'destination')
    
    # Put bucket policy on destination bucket
    put_bucket_policy(destination_bucket, source_bucket_acct_id)
    
    # Replication configuration on source bucket
    put_s3_replication(source_bucket, destination_bucket_acct_id, destination_bucket, replication_role)
    

# Create an destination s3 bucket 
def create_bucket(bucket, region):

    logger.info("in Create of new s3 bucket")
    
    bucket_response = DESTINATION_S3.create_bucket(
        Bucket=bucket)
        # ,
        # CreateBucketConfiguration={
        #   'LocationConstraint': region})



# Replication configuration on s3 bucket
def put_s3_replication(bucket, acctid, dstbucket, role):

    logger.info("Configuring Rules for replication")
    
    SOURCE_S3.put_bucket_replication(
        Bucket= bucket,
        ReplicationConfiguration={
            'Role': role,
            'Rules': [
                {
                    'ID': 'cur-report-replication',
                    'Priority': 1,
                    'Filter': {},
                    'Status': 'Enabled',
                    'Destination': {
                        'Bucket': 'arn:aws:s3:::'+dstbucket,
                        'Account': acctid,
                        'AccessControlTranslation': {
                            'Owner': 'Destination'
                        }
                    },
                    'DeleteMarkerReplication': {
                        'Status': 'Disabled'
                    }
                }      
            ]
        }
    ) 

# Put bucket policy on destination bucket     
def put_bucket_policy(bucket, acctid):

    logger.info("putting bucket policy ")
    
    bucket_policy= {
        "Version": "2008-10-17",
        "Id": "S3-Console-Replication-Policy-v1",
        "Statement": [{
            "Sid": "S3ReplicationPolicyStmt1",
            "Effect": "Allow",
            "Principal": {
                "AWS": "arn:aws:iam::"+acctid+":root"
            },
            "Action": ["s3:GetBucketVersioning", "s3:PutBucketVersioning", "s3:ReplicateObject", "s3:ReplicateDelete", "s3:ObjectOwnerOverrideToBucketOwner"],
            "Resource": ["arn:aws:s3:::"+bucket, "arn:aws:s3:::"+bucket+"/*"]
        }]
        }
    bucket_policy_conversion = json.dumps(bucket_policy)

    bucket_policy_destination = DESTINATION_S3.put_bucket_policy(Bucket= bucket, Policy= bucket_policy_conversion)
    
    
def update_bucket_versioning (bucket, status, target):

    logger.info("in Delete")
    
    if target == 'destination':
      DESTINATION_S3.put_bucket_versioning(
      Bucket= bucket,
      VersioningConfiguration={
          'MFADelete': 'Disabled',
          'Status': status
        }  ) 
    elif target == 'source':
      SOURCE_S3.put_bucket_versioning(
      Bucket= bucket,
      VersioningConfiguration={
          'MFADelete': 'Disabled',
          'Status': status
        }  )

def handler(event, context):
    try:
      HELPER(event, context)
    except Exception as e:
      logger.error("send(..) failed to configure replication : " + str(e)) # reviewnotes: This would result in errors being supressed .i.e logged and not bubbled up. is this intentional?
    
    
    logger.info('In Main Lambda Handler.')
    logger.info(json.dumps(event))


