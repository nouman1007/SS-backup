#!/bin/bash -e
./run-prowler-reports.sh
#./run-prowler-2.sh


